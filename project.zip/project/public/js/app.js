const dropZone = document.getElementById('dropZone');
const fileInput = document.getElementById('fileInput');
const status = document.getElementById('status');
const progressContainer = document.getElementById('progressContainer');
const progress = document.getElementById('progress');
const progressStatus = document.getElementById('progressStatus');

// Prevent default drag behaviors
['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
    dropZone.addEventListener(eventName, preventDefaults, false);
    document.body.addEventListener(eventName, preventDefaults, false);
});

// Highlight drop zone when item is dragged over it
['dragenter', 'dragover'].forEach(eventName => {
    dropZone.addEventListener(eventName, highlight, false);
});

['dragleave', 'drop'].forEach(eventName => {
    dropZone.addEventListener(eventName, unhighlight, false);
});

// Handle dropped files
dropZone.addEventListener('drop', handleDrop, false);
fileInput.addEventListener('change', handleFiles, false);

function preventDefaults(e) {
    e.preventDefault();
    e.stopPropagation();
}

function highlight(e) {
    dropZone.classList.add('dragover');
}

function unhighlight(e) {
    dropZone.classList.remove('dragover');
}

function handleDrop(e) {
    const dt = e.dataTransfer;
    const files = dt.files;
    handleFiles({ target: { files } });
}

function handleFiles(e) {
    const files = e.target.files;
    if (files.length > 0) {
        uploadFile(files[0]);
    }
}

function updateProgress(percent, message) {
    progress.style.width = `${percent}%`;
    progressStatus.textContent = message;
}

function showProgress() {
    progressContainer.style.display = 'block';
    status.innerHTML = '';
    status.className = '';
}

function hideProgress() {
    progressContainer.style.display = 'none';
}

function uploadFile(file) {
    if (file.type !== 'application/pdf') {
        status.innerHTML = 'Please upload a PDF file';
        status.className = 'error';
        return;
    }

    showProgress();
    updateProgress(0, 'Starting upload...');

    const formData = new FormData();
    formData.append('invoice', file);

    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/invoice/process', true);

    xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) {
            const percent = (e.loaded / e.total) * 100;
            updateProgress(percent, 'Uploading file...');
        }
    };

    xhr.onreadystatechange = function() {
        if (xhr.readyState === 3) {
            updateProgress(70, 'Processing invoice with Google Document AI...');
        }
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                updateProgress(100, 'Processing complete! Downloading Excel file...');
                const blob = new Blob([xhr.response], { 
                    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
                });
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'invoice-data.xlsx';
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
                
                setTimeout(() => {
                    hideProgress();
                    status.innerHTML = 'Invoice processed successfully! Excel file downloaded.';
                    status.className = 'success';
                }, 1000);
            } else {
                hideProgress();
                try {
                    const error = JSON.parse(xhr.responseText);
                    status.innerHTML = `Error: ${error.message || 'Failed to process invoice'}`;
                } catch {
                    status.innerHTML = 'Error: Failed to process invoice. Please try again.';
                }
                status.className = 'error';
            }
        }
    };

    xhr.responseType = 'blob';
    xhr.send(formData);
}