import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

export const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const config = {
  port: process.env.PORT || 3000,
  google: {
    projectId: process.env.PROJECT_ID,
    location: process.env.PROCESSOR_LOCATION,
    processorId: process.env.PROCESSOR_ID
  }
};