import { DocumentProcessorServiceClient } from '@google-cloud/documentai';
import { config } from '../config/index.js';

const client = new DocumentProcessorServiceClient();

export async function processDocument(file) {
  try {
    const name = `projects/${config.google.projectId}/locations/${config.google.location}/processors/${config.google.processorId}`;

    const request = {
      name,
      rawDocument: {
        content: file.buffer,
        mimeType: file.mimetype,
      },
    };

    const [result] = await client.processDocument(request);
    return result;
  } catch (error) {
    console.error('Document AI processing error:', error);
    throw new Error('Failed to process document with Google AI');
  }
}